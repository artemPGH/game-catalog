LoomCity - City Building Simulation Game
======================================

Thank you for downloading LoomCity! This is a city building simulation game 
inspired by City Skylines, where you can build and manage your own city.

How to Play:
------------
1. Run LoomCity.exe to start the game
2. Use the menu to start a new game or load a saved game
3. Build your city using various building types:
   - Roads (1, 2, 3 keys)
   - Residential, Commercial, and Industrial zones (4, 5, 6 keys)
   - Public services like Hospitals, Schools, Police stations
   - Utilities like Power plants and Water facilities
   - Entertainment like Parks, Stadiums, and Malls

Controls:
---------
- Left Mouse Button: Build/Select
- Right Mouse Button: Move camera
- Middle Mouse Button: Info mode
- WASD or Arrow Keys: Move camera
- Scroll Wheel: Zoom in/out
- +/- Keys: Change game speed
- Space: Pause/Resume
- F1: Open menu
- ESC: Close menu
- TAB: Change tool page
- 1-9: Quick select building types

Game Modes:
-----------
- Normal Mode: Start with $100,000 and manage your city budget
- Sandbox Mode: Start with $1,000,000 and unlimited resources for creative play

Features:
---------
- Save/Load system to continue your city development
- Different building levels with visual upgrades
- Resource management (power, water, budget)
- Population growth and employment simulation
- City statistics (happiness, education, health, crime, pollution)

System Requirements:
--------------------
- Windows 7 or higher
- 50 MB free disk space

Enjoy building your city!