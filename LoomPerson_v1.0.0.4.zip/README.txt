Loom Person v1.0.0.4 
==================== 
To play the game, run: python loom_person_v1.0.0.4.py 
Requirements: Python 3.x with pygame installed 
Install pygame with: pip install pygame 
